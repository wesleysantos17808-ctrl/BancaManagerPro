package com.example.bancamanagerpro

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import java.text.NumberFormat
import java.util.Locale

private val Bg = Color(0xFF090F0C)
private val Panel = Color(0xFF14221A)
private val Green = Color(0xFF31D17C)
private val Muted = Color(0xFFA6B5AA)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { BancaManagerApp() }
    }
}

@Composable
fun BancaManagerApp() {
    var balance by remember { mutableStateOf("500") }
    var amount by remember { mutableStateOf("50") }
    var odds by remember { mutableStateOf("2.00") }
    val locale = Locale("pt", "BR")
    val money = NumberFormat.getCurrencyInstance(locale)
    val saldo = balance.toDoubleOrNull() ?: 0.0
    val valor = amount.toDoubleOrNull() ?: 0.0
    val odd = odds.toDoubleOrNull() ?: 0.0
    val valid = valor > 0 && odd > 1
    val retorno = if (valid) valor * odd else 0.0
    val lucro = if (valid) retorno - valor else 0.0
    val implied = if (valid) 100.0 / odd else 0.0
    val exposure = if (saldo > 0) valor / saldo * 100 else 0.0

    MaterialTheme(
        colorScheme = darkColorScheme(
            primary = Green,
            background = Bg,
            surface = Panel,
            onBackground = Color.White,
            onSurface = Color.White
        )
    ) {
        Surface(modifier = Modifier.fillMaxSize(), color = Bg) {
            Column(
                modifier = Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(20.dp),
                verticalArrangement = Arrangement.spacedBy(16.dp)
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text("BANCA MANAGER", color = Green, fontSize = 12.sp, fontWeight = FontWeight.Bold, letterSpacing = 2.sp)
                        Text("PRO", color = Color.White, fontSize = 30.sp, fontWeight = FontWeight.ExtraBold)
                    }
                    Text("⚽", fontSize = 34.sp)
                }

                Card(colors = CardDefaults.cardColors(containerColor = Panel), shape = RoundedCornerShape(20.dp)) {
                    Column(Modifier.padding(18.dp)) {
                        Text("SALDO VIRTUAL", color = Muted, fontSize = 12.sp)
                        Text(money.format(saldo), color = Color.White, fontSize = 30.sp, fontWeight = FontWeight.Bold)
                        Text("Simulador educativo • sem dinheiro real", color = Green, fontSize = 12.sp)
                    }
                }

                Text("Simulador de valores", color = Color.White, fontSize = 20.sp, fontWeight = FontWeight.Bold)
                NumberField("Saldo inicial (R$)", balance) { balance = it }
                NumberField("Valor da simulação (R$)", amount) { amount = it }
                NumberField("Odd hipotética", odds) { odds = it }

                if (valid) {
                    Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                        MetricCard("Retorno hipotético", money.format(retorno), Modifier.weight(1f))
                        MetricCard("Resultado líquido", money.format(lucro), Modifier.weight(1f))
                    }
                    Card(colors = CardDefaults.cardColors(containerColor = Panel), shape = RoundedCornerShape(16.dp)) {
                        Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                            Text("Leitura da simulação", color = Green, fontWeight = FontWeight.Bold)
                            Text("Probabilidade implícita da odd: ${"%.2f".format(locale, implied)}%", color = Color.White)
                            Text("Valor em relação ao saldo: ${"%.2f".format(locale, exposure)}%", color = Color.White)
                        }
                    }
                } else {
                    Text("Digite um valor positivo e uma odd maior que 1 para ver os cálculos.", color = Muted)
                }

                Divider(color = Color(0xFF26382D))
                Text("Jogos e dados esportivos", color = Color.White, fontSize = 20.sp, fontWeight = FontWeight.Bold)
                Card(colors = CardDefaults.cardColors(containerColor = Panel), shape = RoundedCornerShape(16.dp)) {
                    Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        Text("Conexão de dados ainda não configurada", color = Green, fontWeight = FontWeight.Bold)
                        Text(
                            "Esta primeira versão não inventa partidas nem odds. Para mostrar jogos, escalações e cotações reais, será necessário integrar uma fonte esportiva atualizada e configurar uma chave de API.",
                            color = Muted,
                            fontSize = 13.sp
                        )
                    }
                }
                Text(
                    "Odds hipotéticas. A probabilidade implícita é um cálculo matemático, não uma previsão. Não há garantia de resultado.",
                    color = Muted,
                    fontSize = 11.sp
                )
                Spacer(Modifier.height(12.dp))
            }
        }
    }
}

@Composable
private fun NumberField(label: String, value: String, onValue: (String) -> Unit) {
    Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
        Text(label, color = Muted, fontSize = 13.sp)
        OutlinedTextField(
            value = value,
            onValueChange = { new -> onValue(new.filter { it.isDigit() || it == '.' || it == ',' }.replace(',', '.')) },
            modifier = Modifier.fillMaxWidth(),
            singleLine = true,
            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
            colors = OutlinedTextFieldDefaults.colors(
                focusedBorderColor = Green,
                unfocusedBorderColor = Color(0xFF405447),
                focusedTextColor = Color.White,
                unfocusedTextColor = Color.White,
                cursorColor = Green
            )
        )
    }
}

@Composable
private fun MetricCard(title: String, value: String, modifier: Modifier = Modifier) {
    Card(modifier = modifier, colors = CardDefaults.cardColors(containerColor = Panel), shape = RoundedCornerShape(16.dp)) {
        Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
            Text(title, color = Muted, fontSize = 11.sp)
            Text(value, color = Green, fontSize = 17.sp, fontWeight = FontWeight.Bold)
        }
    }
}
