# Banca Manager Pro — projeto Android inicial

Aplicativo Android nativo em Kotlin + Jetpack Compose, com:
- tema escuro preto e verde;
- simulador de saldo, valor e odd;
- cálculo de retorno hipotético, resultado líquido e probabilidade implícita;
- aviso explícito quando dados reais de partidas/odds ainda não estão conectados.

## Como gerar o APK
1. Instale o Android Studio em um computador.
2. Abra a pasta `BancaManagerPro_Android` no Android Studio.
3. Aguarde a sincronização do Gradle.
4. Selecione **Build > Build Bundle(s) / APK(s) > Build APK(s)**.
5. O APK de depuração será gerado em `app/build/outputs/apk/debug/app-debug.apk`.

## Dados reais de futebol
Esta versão não finge ter odds ou jogos ao vivo. Para ativar dados reais, escolha um provedor de dados esportivos, obtenha uma chave de API e implemente a integração no app. A disponibilidade de odds depende do provedor, competição e cobertura regional. Nunca coloque uma chave privada diretamente em um app distribuído publicamente; use um backend para protegê-la.

## Observação
O simulador é educativo e usa odds digitadas manualmente. Probabilidade implícita = 100 / odd decimal. Isso não é previsão de resultado nem garantia de retorno.

## Compilar APK pela nuvem (sem computador)
1. Crie uma conta no GitHub e um repositório novo.
2. Extraia este ZIP e envie todo o conteúdo da pasta para o repositório, mantendo a pasta `.github/workflows`.
3. No repositório, abra **Actions**.
4. Escolha **Build Android APK** e toque em **Run workflow**.
5. Quando terminar, abra a execução concluída e baixe o artefato **BancaManagerPro-debug-apk**.
6. Extraia o ZIP do artefato e instale `app-debug.apk` no Android.

A compilação na nuvem pode exigir ajustes se o ambiente Android/Gradle mudar. Este workflow gera um APK de depuração, não um APK publicado na Play Store.
